import React from "react";

const Home = () => {
  return (
    <div
      className="text-center"
      style={{
        width: "100vw",
        height: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <h1 className="diplay-4 mb-5"> Welcome to Pocker Center</h1>
      <h3>Fill your name and start</h3>
      <input type="input" className="w-25 form-control mb-3" />
      <button className="btn btn-success">Start new Game</button>
    </div>
  );
};

export default Home;
