import Room from './Room';

let chosenItems = new Room();

export default chosenItems;